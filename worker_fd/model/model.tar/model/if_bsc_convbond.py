# coding: utf-8
from sqlalchemy import Column, DateTime, Text, VARCHAR
from sqlalchemy.dialects.oracle import NUMBER
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()
metadata = Base.metadata


class IfBscConvbond(Base):
    __tablename__ = 'if_bsc_convbond'

    vc_scode = Column(VARCHAR(20), primary_key=True)
    vc_bond_code = Column(VARCHAR(16), nullable=False)
    l_market = Column(VARCHAR(50), nullable=False)
    en_redeem_interest = Column(VARCHAR(50))
    vc_equity_code = Column(VARCHAR(20))
    l_convert_bdate = Column(VARCHAR(50))
    l_convert_edate = Column(VARCHAR(50))
    en_convert_ratio = Column(VARCHAR(50))
    en_convert_price = Column(VARCHAR(50))
    cl_convert_clause = Column(Text)
    d_updatetime = Column(DateTime, nullable=False)
    vc_source = Column(VARCHAR(20))
    vc_update_operater = Column(VARCHAR(20))

    def __str__(self):
        return   'vc_scode'